<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <iframe src="history.php" frameborder="0" style="width:33%;height:920px"></iframe>
    <iframe src="penancePage.php" frameborder="0" style="width:33%;height:920px"></iframe>
    <iframe src="vehiclePage.php" frameborder="0" style="width:33%; height:920px"></iframe>
</body>
</html>